// src/pages/Home.jsx
import React from "react";

function Home() {
  return (
    <div
      className="home-page"
      style={{
        backgroundImage: `url('https://wallpaperaccess.com/full/4230678.jpg')`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        minHeight: "80vh",
        color: "white", // Ensures text is white
      }}
    >
      <div className="overlay" style={overlayStyles}></div>
      <div className="container text-center position-relative py-5 d-flex justify-content-between align-items-center">
        <div className="text-left">
          <h1 className="display-4 fw-bold">
            Hi, <br />
            I'm <span className="name-highlight">Bibin</span>
            <br />
            <span className="lead">MEARN Stack Developer</span>
          </h1>
          <a href="#contact" className="btn btn-contact btn-lg">
            Contact Me
          </a>
        </div>

        {/* Pentagon shape for photo */}
        <div className="pentagon-frame">
          <img
            src="https://t3.ftcdn.net/jpg/07/13/35/82/360_F_713358254_pM12hayFvGkMbXwU1wERawwC2Tu3Mfpy.jpg"
            alt="Bibi"
            className="pentagon-image"
          />
        </div>
      </div>

      {/* Adding custom styles inside <style> */}
      <style>
        {`
          /* Text styling */
          .name-highlight {
            color: red;  /* Red color for "Bibi" */
          }

          .btn-contact {
            background-color: red;  /* Red background for the contact button */
            color: white;  /* White text color */
            border: none;
            padding: 12px 25px;
            font-size: 1.1rem;
            font-weight: bold;
            text-transform: uppercase;
            border-radius: 5px;  /* Rounded corners */
            transition: background-color 0.3s ease;
            display: inline-block;
            margin-top: 20px;
          }

          .btn-contact:hover {
            background-color: darkred;  /* Dark red color on hover */
            text-decoration: none;  /* Remove underline on hover */
          }

          /* Pentagon shape for photo */
          .pentagon-frame {
            width: 250px; /* Increase width */
            height: 250px; /* Increase height */
            position: relative;
            overflow: hidden;
            margin-top: -50px; /* Adjust positioning of the frame */
          }

          .pentagon-frame::before {
            content: '';
            position: absolute;
            top: 0;
            left: 50%;
            width: 0;
            height: 0;
            border-left: 125px solid transparent; /* Adjust border size */
            border-right: 125px solid transparent;
            border-bottom: 175px solid #fff; /* Adjust bottom border size */
            transform: translateX(-50%);
          }

          .pentagon-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            clip-path: polygon(50% 0%, 0% 25%, 0% 75%, 50% 100%, 100% 75%, 100% 25%);
            border-radius: 15px;  /* Soften the edges of the pentagon with border-radius */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);  /* Add shadow for depth */
          }

          /* Lead text styling */
          .lead {
            font-size: 2rem;
          }

          /* Align text to left */
          .text-left {
            flex: 1;
            text-align: left;
          }

          /* Overlay for the background image */
          .overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5); /* Dark transparent overlay */
            z-index: -1; /* Ensure content stays on top */
          }

          /* Responsive styling for smaller screens */
          @media (max-width: 768px) {
            .home-page {
              text-align: center;
            }

            .pentagon-frame {
              margin-top: 20px;
              width: 200px;
              height: 200px; /* Adjust size for smaller screens */
            }

            .text-left {
              text-align: center;  /* Center text on small screens */
              flex: none;
            }
          }
        `}
      </style>
    </div>
  );
}

// Overlay for the background image (Darkens the image to make text more readable)
const overlayStyles = {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: "rgba(0, 0, 0, 0.5)", // Dark transparent overlay
  zIndex: -1, // Ensures content stays on top of the overlay
};

export default Home;
