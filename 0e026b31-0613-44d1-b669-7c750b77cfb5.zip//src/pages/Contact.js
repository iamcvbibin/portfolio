// src/pages/Contact.js
import React from "react";

function Contact() {
  return (
    <div>
      <h1>Contact Me</h1>
      <p>Email: bibi@example.com</p>
      <p>
        LinkedIn: <a href="https://www.linkedin.com">linkedin.com/in/bibi</a>
      </p>
    </div>
  );
}

export default Contact;
