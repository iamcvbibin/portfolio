// src/pages/Projects.js
import React from "react";

function Projects() {
  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">My Projects</h2>

      <div className="row">
        {/* Animal Welfare Website */}
        <div className="col-md-4 mb-4">
          <div className="card h-100">
            {" "}
            {/* h-100 makes sure the card stretches to full height */}
            <img
              src="https://colorlib.com/wp/wp-content/uploads/sites/2/1_pet-care-websites.jpg" // Image for Animal Welfare Website
              className="card-img-top"
              alt="Animal Welfare Website"
              style={{ objectFit: "cover", height: "250px" }} // Fixed height for consistency
            />
            <div className="card-body d-flex flex-column">
              {" "}
              {/* Flexbox to stretch content */}
              <h5 className="card-title">Animal Welfare Website</h5>
              <p className="card-text">
                A platform dedicated to advancing animal rights, providing
                valuable resources for education, adoption, and ways to support
                the ethical treatment and well-being of animals.
              </p>
              <a
                href="/projects/animal-welfare"
                className="btn btn-primary mt-auto"
              >
                View Project
              </a>
            </div>
          </div>
        </div>

        {/* Furniture Selling Website */}
        <div className="col-md-4 mb-4">
          <div className="card h-100">
            <img
              src="https://agentestudio.com/uploads/ckeditor/pictures/935/content_pic_1.png" // Image for Furniture Selling Website
              className="card-img-top"
              alt="Furniture Selling Website"
              style={{ objectFit: "cover", height: "250px" }}
            />
            <div className="card-body d-flex flex-column">
              <h5 className="card-title">Furniture Selling Website</h5>
              <p className="card-text">
                An online marketplace offering a diverse selection of premium
                furniture pieces, tailored to fit every home aesthetic and
                budget, helping customers transform their living spaces with
                style and functionality.
              </p>
              <a
                href="/projects/furniture-selling"
                className="btn btn-primary mt-auto"
              >
                View Project
              </a>
            </div>
          </div>
        </div>

        {/* Git Login Page */}
        <div className="col-md-4 mb-4">
          <div className="card h-100">
            <img
              src="https://user-images.githubusercontent.com/76609302/172825370-c323b652-ad37-4244-94ff-51105516039f.png" // Image for Git Login Page
              className="card-img-top"
              alt="Git Login Page"
              style={{ objectFit: "cover", height: "250px" }}
            />
            <div className="card-body d-flex flex-column">
              <h5 className="card-title">Git Login Page</h5>
              <p className="card-text">
                A secure login interface designed for seamless access to Git
                accounts, empowering users to manage repositories, collaborate
                on coding projects, and track development progress across
                multiple branches.
              </p>
              <a href="/projects/git-login" className="btn btn-primary mt-auto">
                View Project
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Projects;
