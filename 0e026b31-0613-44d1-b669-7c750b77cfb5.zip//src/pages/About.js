// src/pages/About.js
import React from "react";

function About() {
  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4 text-white">About Me</h2>

      {/* Profile Image and Description */}
      <div className="row">
        <div className="col-md-4 mb-4">
          <div className="card h-100 border-0 shadow-lg bg-dark text-light">
            <img
              src="https://cdn.pixabay.com/photo/2021/08/04/13/06/software-developer-6521720_1280.jpg" // Profile image
              className="card-img-top"
              alt="Profile"
              style={{
                objectFit: "cover",
                height: "300px",
                borderRadius: "10px 10px 0 0",
              }}
            />
            <div className="card-body d-flex flex-column">
              <h5 className="card-title text-danger">Bibi's Profile</h5>{" "}
              {/* Red text for title */}
              <p className="card-text">
                I am a passionate Full Stack Developer with expertise in the
                MEARN stack. I specialize in building responsive and scalable
                web applications. I enjoy creating innovative solutions that
                solve real-world problems.
              </p>
              <a href="#contact" className="btn btn-danger mt-auto shadow-lg">
                {" "}
                {/* Red button */}
                Contact Me
              </a>
            </div>
          </div>
        </div>

        {/* Skills Section */}
        <div className="col-md-8 mb-4">
          <div className="card h-100 border-0 shadow-lg bg-dark text-light">
            <div className="card-body d-flex flex-column">
              <h5 className="card-title text-danger">Skills</h5>{" "}
              {/* Red text for title */}
              <p className="card-text">
                Over the years, I have gained proficiency in a range of
                programming languages, frameworks, and tools. Below are the
                technologies I am skilled in:
              </p>
              <ul className="list-group list-group-flush">
                <li className="list-group-item bg-dark text-light border-0">
                  JavaScript (ES6+)
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  React.js
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  Node.js
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  Express.js
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  MongoDB
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  HTML5 / CSS3
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  Git & GitHub
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  RESTful APIs
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Experience Section */}
      <div className="row">
        <div className="col-12 mb-4">
          <div className="card h-100 border-0 shadow-lg bg-dark text-light">
            <div className="card-body d-flex flex-column">
              <h5 className="card-title text-danger">Experience</h5>{" "}
              {/* Red text for title */}
              <p className="card-text">
                I have worked on various web development projects, from creating
                personal websites to building full-scale applications for
                clients. I thrive in team settings and enjoy collaborating with
                others to bring ideas to life. Here are some highlights:
              </p>
              <ul className="list-group list-group-flush">
                <li className="list-group-item bg-dark text-light border-0">
                  Developed and maintained full-stack applications
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  Integrated REST APIs and handled complex data management
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  Built responsive UIs using React and Material UI
                </li>
                <li className="list-group-item bg-dark text-light border-0">
                  Collaborated with teams on Agile projects
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
