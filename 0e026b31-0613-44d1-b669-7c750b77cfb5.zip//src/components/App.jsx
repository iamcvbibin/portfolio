// src/components/App.jsx
import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "../pages/Home";
import About from "../pages/About";
import Projects from "../pages/Projects";
import Contact from "../pages/Contact";

function App() {
  return (
    <Router>
      <div>
        {/* Dark theme navbar with additional space */}
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          {/* Wrapper for the navbar content with container */}
          <div
            className="container"
            style={{ paddingLeft: "40px", paddingRight: "40px" }}
          >
            <div className="d-flex justify-content-between align-items-center w-100">
              {/* Left side - Profile Image */}
              <div
                className="navbar-img"
                style={{
                  width: "60px",
                  height: "60px",
                  overflow: "hidden",
                  borderRadius: "50%",
                }}
              >
                <img
                  src="https://t3.ftcdn.net/jpg/05/20/80/86/240_F_520808688_oQ6yuXaNZi5Lf0dxjUXeIQSWPeIINEMI.jpg"
                  alt="Bibi's Profile"
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
              </div>

              {/* Right side - Navbar links */}
              <div
                className="navbar-nav d-flex justify-content-end"
                style={{ marginLeft: "auto" }}
              >
                <a
                  className="nav-link"
                  href="/"
                  style={{
                    fontWeight: "600",
                    textTransform: "capitalize",
                    marginLeft: "30px",
                  }}
                >
                  Home
                </a>
                <a
                  className="nav-link"
                  href="/about"
                  style={{
                    fontWeight: "600",
                    textTransform: "capitalize",
                    marginLeft: "30px",
                  }}
                >
                  About
                </a>
                <a
                  className="nav-link"
                  href="/projects"
                  style={{
                    fontWeight: "600",
                    textTransform: "capitalize",
                    marginLeft: "30px",
                  }}
                >
                  Projects
                </a>
                <a
                  className="nav-link"
                  href="/contact"
                  style={{
                    fontWeight: "600",
                    textTransform: "capitalize",
                    marginLeft: "30px",
                  }}
                >
                  Contact
                </a>
              </div>
            </div>
          </div>
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>

        {/* Footer with social media icons */}
        <footer className="bg-dark text-white text-center py-4">
          <p>&copy; 2024. All rights reserved.</p>

          {/* Social Media Icons */}
          <div className="social-icons">
            <a
              href="https://www.facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="social-icon"
            >
              <i className="fab fa-facebook fa-2x"></i>
            </a>
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="social-icon"
            >
              <i className="fab fa-instagram fa-2x"></i>
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="social-icon"
            >
              <i className="fab fa-twitter fa-2x"></i>
            </a>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="social-icon"
            >
              <i className="fab fa-github fa-2x"></i>
            </a>
          </div>
        </footer>
      </div>

      {/* Custom CSS styles for navbar links, hover effect, and social icons */}
      <style>
        {`
          /* Navbar links */
          .navbar-nav .nav-link {
            font-size: 1.1rem; /* Slightly larger text */
            color: white !important; /* White color for links */
            text-transform: capitalize; /* Capitalize only the first letter */
            font-weight: 600; /* Medium font weight */
            transition: color 0.3s ease;
            position: relative;
          }

          /* Hover effect: Underline that animates left to right */
          .navbar-nav .nav-link:hover {
            color: red !important; /* Red color on hover */
          }

          .navbar-nav .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background-color: red;
            transition: width 0.3s ease;
          }

          .navbar-nav .nav-link:hover::after {
            width: 100%;
          }

          /* Active link color */
          .navbar-nav .nav-link.active {
            color: red !important; /* Red color for active link */
            font-weight: bold;
          }

          /* Navbar background color */
          .navbar-dark .navbar-nav .nav-link {
            color: white !important; /* Ensures text is white */
          }

          /* Navbar background */
          .navbar {
            background-color: #343a40 !important; /* Dark background */
          }

          /* Footer styles */
          .social-icons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 15px;
          }

          .social-icon {
            color: white;
            text-decoration: none;
          }

          .social-icon:hover {
            color: red; /* Red color on hover for social icons */
          }

          .social-icon i {
            transition: color 0.3s ease;
          }

          /* Mobile responsive adjustments */
          @media (max-width: 768px) {
            .navbar-nav .nav-item {
              margin-left: 15px;
            }

            .navbar-img {
              display: none; /* Hide image on small screens */
            }
          }
        `}
      </style>
    </Router>
  );
}

export default App;
